import {
  EventMapBase,
  NavigationState,
  RouteConfig,
} from '@react-navigation/native';

import Messages1, {Messages1RouteParams} from './Messages1';
import Messages2, {Messages2RouteParams} from './Messages2';
import Messages3, {Messages3RouteParams} from './Messages3';

export type MessagesParamList = {
  Messages1RouteName: Messages1RouteParams;
  Messages2RouteName: Messages2RouteParams;
  Messages3RouteName: Messages3RouteParams;
};
type RouteName = keyof MessagesParamList;
type RouteState = NavigationState;
type ScreenOptions = {};
type EventMap = EventMapBase;

type MessageRouteConfig = RouteConfig<
  MessagesParamList,
  RouteName,
  RouteState,
  ScreenOptions,
  EventMap
>;

export const MessagesScreenConfigs: MessageRouteConfig[] = [
  {name: 'Messages1RouteName', component: Messages1},
  {name: 'Messages2RouteName', component: Messages2},
  {name: 'Messages3RouteName', component: Messages3},
];
