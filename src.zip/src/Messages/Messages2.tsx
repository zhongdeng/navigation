import React from 'react';
import {Text, View, StyleSheet} from 'react-native';

export type Messages2RouteParams = {
  params1: number;
  params2: string;
  params3: boolean;
};

export default () => {
  return (
    <View style={styles.container}>
      <Text>Message2</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
