import React from 'react';
import {StackScreenProps, StackNavigationProp} from '@react-navigation/stack';
import {
  CompositeScreenProps,
  NavigationContainer,
} from '@react-navigation/native';
import {
  BottomTabScreenProps,
  createBottomTabNavigator,
} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import {TabRootScreenConfigs, TabRootScreenParamList} from './TabScreen';
import {FeedScreenConfigs, FeedParamList} from '../Feed';
import {MessagesScreenConfigs, MessagesParamList} from '../Messages';

type RootTabParamList = TabRootScreenParamList;
type RootStackParamList = {
  Home: undefined;
} & MessagesParamList &
  FeedParamList;

const Tab = createBottomTabNavigator<RootTabParamList>();
const Stack = createNativeStackNavigator<RootStackParamList>();

const Home = () => {
  return (
    <Tab.Navigator>
      {TabRootScreenConfigs.map(config => (
        <Tab.Screen key={config.name} {...config} />
      ))}
    </Tab.Navigator>
  );
};

const Main = () => {
  return (
    <NavigationContainer
      ref={navigator => {
        console.log(navigator);
      }}>
      <Stack.Navigator>
        <Stack.Screen
          name="Home"
          component={Home}
          options={{headerShown: false}}
        />
        {MessagesScreenConfigs.map(config => (
          <Stack.Screen key={config.name} {...config} />
        ))}
        {FeedScreenConfigs.map(config => (
          <Stack.Screen key={config.name} {...config} />
        ))}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export type AllParamList = RootTabParamList & RootStackParamList;
export type NavigationProps = StackNavigationProp<AllParamList>;

export type RootStackScreenProps<T extends keyof RootStackParamList> =
  StackScreenProps<RootStackParamList, T>;
export type RootTabScreenProps<T extends keyof RootTabParamList> =
  CompositeScreenProps<
    BottomTabScreenProps<RootTabParamList, T>,
    RootStackScreenProps<keyof RootStackParamList>
  >;

export default Main;
