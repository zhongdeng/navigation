import {NavigationState} from '@react-navigation/native';
import {NavigationProps} from './Main';

class Navigator {
  private navigator: NavigationState<> | null = null;

  public init = (navigator: NavigationState) => {
    this.navigator = navigator;
  };

  public navigate = () => {
    this.navigate();
  };
}

export default Navigator;
