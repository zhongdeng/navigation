import {
  EventMapBase,
  NavigationState,
  RouteConfig,
} from '@react-navigation/native';

import TabRoot1, {TabRoot1RouteParams} from './TabRoot1';
import TabRoot2, {TabRoot2RouteParams} from './TabRoot2';
import TabRoot3, {TabRoot3RouteParams} from './TabRoot3';

export type TabRootScreenParamList = {
  TabRoot1RouteName: TabRoot1RouteParams;
  TabRoot2RouteName: TabRoot2RouteParams;
  TabRoot3RouteName: TabRoot3RouteParams;
};
type RouteName = keyof TabRootScreenParamList;
type RouteState = NavigationState;
type ScreenOptions = {};
type EventMap = EventMapBase;

type TabRootScreenRouteConfig = RouteConfig<
  TabRootScreenParamList,
  RouteName,
  RouteState,
  ScreenOptions,
  EventMap
>;

export const TabRootScreenConfigs: TabRootScreenRouteConfig[] = [
  {
    name: 'TabRoot1RouteName',
    component: TabRoot1,
    options: {title: 'Tab1'},
  },
  {
    name: 'TabRoot2RouteName',
    component: TabRoot2,
    options: {title: 'Tab2'},
  },
  {
    name: 'TabRoot3RouteName',
    component: TabRoot3,
    options: {title: 'Tab3'},
  },
];
