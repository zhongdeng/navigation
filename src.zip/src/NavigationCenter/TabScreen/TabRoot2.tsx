import React from 'react';
import {useRoute} from '@react-navigation/native';
import {Text, View, StyleSheet} from 'react-native';
import {RootTabScreenProps} from '../Main';

export type TabRoot2RouteParams = {
  from: string;
};

export default () => {
  const route = useRoute<RootTabScreenProps<'TabRoot2RouteName'>['route']>();
  return (
    <View style={styles.container}>
      <Text>TabRoot2</Text>
      <Text>{`from: ${route.params.from}`}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
