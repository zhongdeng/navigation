import React from 'react';
import {useNavigation} from '@react-navigation/native';
import {Text, View, StyleSheet, Button} from 'react-native';
import {RootTabScreenProps} from '../Main';

export type TabRoot1RouteParams = {
  from: string;
};

export default () => {
  const navigation =
    useNavigation<RootTabScreenProps<'TabRoot1RouteName'>['navigation']>();
  return (
    <View style={styles.container}>
      <Text>TabRoot1</Text>
      <Button
        title="Root2"
        onPress={() => {
          navigation.navigate('TabRoot2RouteName', {from: 'TabRoot1'});
        }}
      />
      <Button
        title="Feed1"
        onPress={() => {
          navigation.navigate('Feed1RouteName', {from: 'TabRoot1'});
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
