import {
  EventMapBase,
  NavigationState,
  RouteConfig,
} from '@react-navigation/native';

import Feed1, {Feed1RouteParams} from './Feed1';
import Feed2, {Feed2RouteParams} from './Feed2';
import Feed3, {Feed3RouteParams} from './Feed3';

export type FeedParamList = {
  Feed1RouteName: Feed1RouteParams;
  Feed2RouteName: Feed2RouteParams;
  Feed3RouteName: Feed3RouteParams;
};
type RouteName = keyof FeedParamList;
type RouteState = NavigationState;
type ScreenOptions = {};
type EventMap = EventMapBase;

type MessageRouteConfig = RouteConfig<
  FeedParamList,
  RouteName,
  RouteState,
  ScreenOptions,
  EventMap
>;

export const FeedScreenConfigs: MessageRouteConfig[] = [
  {name: 'Feed1RouteName', component: Feed1},
  {name: 'Feed2RouteName', component: Feed2},
  {name: 'Feed3RouteName', component: Feed3},
];
