import React from 'react';
import {useNavigation, useRoute} from '@react-navigation/native';
import {Text, View, StyleSheet, Button} from 'react-native';
import {RootTabScreenProps, NavigationProps} from '../NavigationCenter/Main';

export type Feed1RouteParams = {
  from: string;
};

export default () => {
  const route = useRoute<RootTabScreenProps<'TabRoot1RouteName'>['route']>();
  const navigation = useNavigation<NavigationProps>();

  return (
    <View style={styles.container}>
      <Text>Feed1</Text>
      <Text>{`from: ${route.params.from}`}</Text>
      <Button
        title="Root2"
        onPress={() => {
          navigation.navigate('TabRoot2RouteName', {from: 'Feed1'});
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
